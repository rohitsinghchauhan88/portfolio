window.addEventListener('load',()=>console.log('Portfolio Loaded Successfully'));
const year=document.getElementById('year');
if(year){year.textContent=new Date().getFullYear();}
